# 안드로이드 프로그래밍(2) 14주차 / 2020. 12. 01.

## Adapter

* AdapterView의 구현이 요구됨

## ViewPager

* 원본 데이터(Fragment)를 연결해두면, 내부적으로 렌더링 및 액션 처리

## 서비스와 수신자

### 개요

* 외부 서비스(API)와의 통신을 통해 보다 효과적으로 기능을 구현할 수 있다.

### Service

### BroadCast Recevier

* 브로드캐스트 수신자는 인텐트 필터를 포함
* 매니페스트 파일에 등록함으로써 인텐트를 받을 준비를 함

### Content Provider

## 프로세스와 쓰레드

### 프로세스 단위의 작업

* 공통영역 사용 시 Context Switching에 의한 오버헤드가 발생

### Register Set

* i: Function Call 시 전달되는 변수
* o: ?
* l: ?
* g: Global Variable
* 레지스터에 변수/함수 스택 주소 저장

## 