# 자료구조 실습 / 2020. 11. 19. (목)

## 시작

* Data를 어떤 식으로 저장할 것무인가?
* 저장한 Data를 나중에 활용할 때, 저장한 순서가 빠른 것부터 꺼내 사용(FIFO)
  * 큐(Queue)
  * 구현: 배열
    * 선형 큐(Linear Queue)
    * 원형 큐(Circular Queue)

## 덱(Deque; Double-Ended Queue)

### 개요

* 양방향 큐(앞-뒤로 Inqueue-Dequeue 가능)
* 선형, 원형 모두 가능

## 연결 리스트(Linked List)

### 개요

* 배열의 단점을 해결한 자료구조
* 