#include <stdio.h>

int main(void)
{
    int a[10][20];

    printf("%d\n", sizeof(a));

    return 0;
}