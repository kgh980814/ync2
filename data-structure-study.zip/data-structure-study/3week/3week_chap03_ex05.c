#include <stdio.h>

struct person {
    char name[255];
    int age;
    float salary;
};

int main(void)
{
    return 0;
}
