#include <stdio.h>

typedef struct complex {
    float real;
    float imaginary;
} complex;

int main(void)
{
    complex c1;
    complex c2;

    return 0;
}
