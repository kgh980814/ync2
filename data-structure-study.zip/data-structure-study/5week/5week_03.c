#include <stdio.h>

int main(void)
{
    int A[6] = { 2, 4, 6, 8, 10, 12 };
    int i;

    for (i = 0; i < 6; ++i) {
        printf("%d ", &A[i]);
    }

    return 0;
}