public class AndroidPhone implements ISmartPhone{
    @Override
    public void internet() {

    }

    @Override
    public void takePicture() {

    }

    @Override
    public void recordMovie() {

    }

    @Override
    public void web() {

    }

    @Override
    public void listen() {

    }

    @Override
    public void callNum() {

    }

    @Override
    public void receiveCall() {

    }
}
