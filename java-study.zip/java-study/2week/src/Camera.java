public interface Camera {
    void takePicture();
    public abstract void recordMovie();
}
