public interface Car {
    int MAXIMUM_SPEED = 260;

    void moveHandle(int degree);
    void changeGear(int gear);
}
