public interface Internet {
    void web();
}
