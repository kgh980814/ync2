public interface MP3 {
    public abstract void listen();
}
