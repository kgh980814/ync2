public interface Phone {
    void callNum();
    void receiveCall();
}
