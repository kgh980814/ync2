public interface RollMouseInterface {
//    void roll();
    public abstract void roll();
}
