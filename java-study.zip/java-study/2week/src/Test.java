public abstract class Test {
    private int num;
    
    public abstract void doA(); // 추상 메소드

}
