public interface USBMouseInterface {
    void mouseMove(); // 추상 메소드

    public abstract void mouseClick();
}
