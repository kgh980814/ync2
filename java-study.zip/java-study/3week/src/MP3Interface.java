public interface MP3Interface {
    public void play();
    public void stop();
}
