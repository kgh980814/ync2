public interface MobilePhoneInterface extends PhoneInterface {
    void sendSMS();
    void receiveSMS();
}
