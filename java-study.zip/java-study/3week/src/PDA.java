public class PDA {
    public int calculate(int x, int y) {
        return x + y;
    }
}
