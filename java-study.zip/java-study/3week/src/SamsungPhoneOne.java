public class SamsungPhoneOne extends PDA implements MobilePhoneInterface, MP3Interface {

    @Override
    public void play() {

    }

    @Override
    public void stop() {

    }

    @Override
    public void sendSMS() {

    }

    @Override
    public void receiveSMS() {

    }

    @Override
    public void sendCall() {

    }

    @Override
    public void receiveCall() {

    }
}
