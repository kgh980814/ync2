public class StringEx2 {
    public static void main(String[] args) {
        String str = "abcd";
        System.out.println(str.toUpperCase());

        System.out.println(str.charAt(3));

        String str1 = "    abcdE    ";
        System.out.println(str1.trim());

        System.out.println("100" + 100);
        System.out.println(100 + 100);
    }
}
