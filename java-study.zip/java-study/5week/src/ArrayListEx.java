import java.util.ArrayList;

public class ArrayListEx {
    public static void main(String[] args) {
        ArrayList list = new ArrayList();

        list.add("Kim");
        list.add("Lee");
        list.add("Kim");
        list.add("Park");
        list.add("Choi");

        System.out.println(list);
    }
}
