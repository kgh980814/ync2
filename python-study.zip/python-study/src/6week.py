##
# 6주차 진도
##
import random

print(random.random())
print(random.randint(1, 20))
x = ['A', 'B', 'C', 'D', 'E']
print(random.choice(x))
