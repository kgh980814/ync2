cities = "서울,대전,대구,부산,제주"
cities = cities.split(',')
cities.sort()
print(cities)
