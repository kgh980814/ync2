song_rate = {
    "Dynamite": 5,
    "WAP": 3,
    "Laugh Now Cry Later": 4,
    "Rockstar": 4,
    "Blinding Lights": 5
}

for key in song_rate.keys():
    if song_rate[key] == 5:
        print(key)
